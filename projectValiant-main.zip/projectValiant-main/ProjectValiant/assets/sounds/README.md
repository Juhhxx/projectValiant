Place .wav, .sav or .vgm files in this folder to use them as sound effects in your game

Docs: https://www.gbstudio.dev/docs/assets/sound-effects
