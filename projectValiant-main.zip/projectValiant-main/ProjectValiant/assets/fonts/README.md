Place .png and .json mapping files in this folder to use them as fonts in your dialogues

Docs: https://www.gbstudio.dev/docs/settings/#ui-elements--fonts
